package servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import service.CardapioService;
import to.CardapioTO;

/**
 * Servlet implementation class CardapioController
 */
@WebServlet("/ManterCardapio.do")
public class CardapioController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CardapioController() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		if(request.getParameter("tipoOperacao").equals("Alterar"))
		{
			int codprod = Integer.parseInt(request.getParameter("codigo"));
			
			CardapioTO cto = new CardapioTO();
			cto.setNumero(codprod);
			
			CardapioService cserv = new CardapioService();
			cserv.consultar(cto);
			
			request.setAttribute("cardapio", cto);
			
			RequestDispatcher view = request.getRequestDispatcher("AlterarCardapio.jsp");
			view.forward(request, response);	
			
//			PrintWriter out = response.getWriter();
//			out.println("<html><head><title>Alterar Cardapio</title></head><body>");
//			out.println( "C�digo do Produto: "+cto.getNumero()+"<br>");
//			out.println( "Valor: "+cto.getValorUnit()+"<br>");
//			out.println( "Nome do Produto: "+cto.getDescricao()+"<br>");
//			out.println( "<br><br>");
//			out.println( "<form action= 'ManterCardapio.do' method='post'>");
//			out.println( "<input type='hidden' name='codigo' value='"+cto.getNumero()+"'><br>");
//			out.println( "Valor: <input type='text' name='valor'><br>");
//			out.println( "Nome do Produto: <input type='text' name='nome_produto'><br>");
//			out.println( "<input type='hidden' value='Alterar' name='tipoOperacao'>");
//			out.println( "<input type='submit' value='Alterar'>");
//			out.println( "<a href='ManterCardapio.html'><input type='submit' value='Voltar'></a>");
//			out.println( "</form>");
//			out.println("</body></html>");
			
		}
		else if(request.getParameter("tipoOperacao").equals("Consultar"))
		{
			int codprod = Integer.parseInt(request.getParameter("codigo"));
			
			CardapioTO cto = new CardapioTO();
			cto.setNumero(codprod);
			
			CardapioService cserv = new CardapioService();
			cserv.consultar(cto);
			
			request.setAttribute("cardapio", cto);
			
			RequestDispatcher view = request.getRequestDispatcher("ConsultarCardapio.jsp");
			view.forward(request, response);
			
//			PrintWriter out = response.getWriter();
//			out.println("<html><head><title>Consulta de Cardapio</title></head><body>");
//			out.println( "C�digo do Produto: "+cto.getNumero()+"<br>");
//			out.println( "Valor: "+cto.getValorUnit()+"<br>");
//			out.println( "Nome do Produto: "+cto.getDescricao()+"<br>");
//			out.println( "<a href='ManterCardapio.html'><input type='submit' value='Voltar'></a>");
//			out.println("</body></html>");
		}
		else if(request.getParameter("tipoOperacao").equals("Excluir"))
		{
			int codprod = Integer.parseInt(request.getParameter("codigo"));
			
			CardapioTO cto = new CardapioTO();
			cto.setNumero(codprod);
			
			CardapioService cserv = new CardapioService();
			cserv.consultar(cto);
			
			request.setAttribute("cardapio", cto);
			
			RequestDispatcher view = request.getRequestDispatcher("ExcluirCardapio.jsp");
			view.forward(request, response);
			
//			PrintWriter out = response.getWriter();
//			out.println("<html><head><title>Alterar Cardapio</title></head><body>");
//			out.println( "C�digo do Produto: "+cto.getNumero()+"<br>");
//			out.println( "Valor: "+cto.getValorUnit()+"<br>");
//			out.println( "Nome do Produto: "+cto.getDescricao()+"<br>");
//			out.println( "<br><br>");
//			out.println( "<form action= 'ManterCardapio.do' method='post'>");
//			out.println( "<input type='hidden' name='codigo' value='"+cto.getNumero()+"'><br>");
//			out.println( "<input type='hidden' value='Excluir' name='tipoOperacao'>");
//			out.println( "<h2>Deseja mesmo excluir?</h2>");
//			out.println( "<input type='submit' value='Excluir'>");
//			out.println( "</form>");
//			out.println("</body></html>");
			
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		if(request.getParameter("tipoOperacao").equals("Cadastrar"))
		{
			int codprod = Integer.parseInt(request.getParameter("codigo"));
			double valorprod = Double.parseDouble(request.getParameter("valor"));
			String nomeprod = request.getParameter("nome_produto");
			
			CardapioTO cto = new CardapioTO();
			cto.setNumero(codprod);
			cto.setValorUnit(valorprod);
			cto.setDescricao(nomeprod);
			
			CardapioService cserv = new CardapioService();
			cserv.criar(cto);
			
			request.setAttribute("cardapio", cto);
			
			RequestDispatcher view = request.getRequestDispatcher("CadastrarCardapio.jsp");
			view.forward(request, response);
			
//			PrintWriter out = response.getWriter();
//			out.println("<html><head><title>Cardapio Registrado</title></head><body>");
//			out.println( "C�digo do Produto: "+cto.getNumero()+"<br>");
//			out.println( "Valor: "+cto.getValorUnit()+"<br>");
//			out.println( "Nome do Produto: "+cto.getDescricao()+"<br>");
//			out.println( "<a href='ManterCardapio.html'><input type='submit' value='Voltar'></a>");
//			out.println("</body></html>");
		}
		else if(request.getParameter("tipoOperacao").equals("Alterar"))
		{
			int codprod = Integer.parseInt(request.getParameter("codigo"));
			double valorprod = Double.parseDouble(request.getParameter("valor"));
			String nomeprod = request.getParameter("nome_produto");
			
			CardapioTO cto = new CardapioTO();
			cto.setNumero(codprod);
			cto.setValorUnit(valorprod);
			cto.setDescricao(nomeprod);
			
			CardapioService scerv = new CardapioService();
			scerv.alterar(cto);
			
			request.setAttribute("cardapio", cto);
			
			RequestDispatcher view = request.getRequestDispatcher("AlterarCardapio2.jsp");
			view.forward(request, response);
			
//			PrintWriter out = response.getWriter();
//			out.println("<html><head><title>Cardapio Alterado</title></head><body>");
//			out.println( "C�digo do Produto: "+cto.getNumero()+"<br>");
//			out.println( "Valor: "+cto.getValorUnit()+"<br>");
//			out.println( "Nome do Produto: "+cto.getDescricao()+"<br>");
//			out.println("</body></html>");
		}
		else if(request.getParameter("tipoOperacao").equals("Excluir"))
		{
			int codprod = Integer.parseInt(request.getParameter("codigo"));
			
			CardapioTO cto = new CardapioTO();
			cto.setNumero(codprod);
			
			CardapioService cserv = new CardapioService();
			cserv.excluir(cto);
			
			request.setAttribute("cardapio", cto);
			
			RequestDispatcher view = request.getRequestDispatcher("ExcluirCardapio2.jsp");
			view.forward(request, response);
			
			
//			PrintWriter out = response.getWriter();
//			out.println("<html><head><title>Cardapio Excluido</title></head><body>");
//			out.println("<h3>Produto Exclu�do</h3>");
//			out.println( "<a href='ManterCardapio.html'><input type='submit' value='Voltar'></a>");
//			out.println("</body></html>");
			
		}
	}

}
