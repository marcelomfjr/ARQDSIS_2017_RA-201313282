package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import banco.ConnectionFactory;
import telas.Login;
import to.PedidoTO;

public class PedidoDAO {

	public PedidoDAO() {

	}

	public void incluir(PedidoTO ca) {
		String sql = "insert into PEDIDO (numero,mesa,data_Entrada,garcom) values (?,?,?,?)";

		try {
			Connection con = ConnectionFactory.obtemConexao();
			PreparedStatement prep = con.prepareStatement(sql);
			prep.setInt(1, ca.getNumero());
			prep.setInt(2, ca.getMesa());
			prep.setString(3, ca.getEntrada());
			prep.setString(4, Login.getNomeUsuario());

			System.out.println(prep.toString());
			prep.execute();
			prep.close();
		} catch (Exception e) {
			e.printStackTrace();

		}
	}

	public PedidoTO consultar(PedidoTO ca) {
		String sqlSelect = "SELECT * FROM Pedido WHERE numero = ?";

		PreparedStatement stm = null;
		ResultSet rs = null;
		try {
			Connection conn = ConnectionFactory.obtemConexao();
			stm = conn.prepareStatement(sqlSelect);
			stm.setInt(1, ca.getNumero());
			rs = stm.executeQuery();
			if (rs.next()) {
				ca.setNumero(rs.getInt("numero"));
				ca.setMesa(rs.getInt("mesa"));
				// ca.setValorUnit(rs.getDouble("valor_unitario"));
				// ca.setDispPrato(rs.getBoolean("disponibilidade_do_prato"));
				ca.setGarcom(rs.getString("garcom"));
			}
			stm.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ca;

	}
	
	public int consultar2(PedidoTO ca) {
		String sqlSelect = "SELECT count(numero) FROM Pedido where numero = ?";

		PreparedStatement stm = null;
		ResultSet rs = null;
		int f = 0;
		try {
			Connection conn = ConnectionFactory.obtemConexao();
			stm = conn.prepareStatement(sqlSelect);
			stm.setInt(1, ca.getNumero());
			rs = stm.executeQuery();
			
			
			if (rs.next()) {
				f = rs.getInt("count(numero)");
			}
			stm.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		finally{
			
		}
		return f;

	}
	
	public PedidoTO consultar3(PedidoTO ca) {
		String sqlSelect = "SELECT * FROM Pedido INNER JOIN ITEM_PEDIDO ON pedido.numero = "
				+ "item_pedido.Pedido_numero where pedido.numero = ? "
				+ "order by item_pedido.Pedido_numero, item_pedido.Cardapio_numero";

		PreparedStatement stm = null;
		ResultSet rs = null;
		try {
			Connection conn = ConnectionFactory.obtemConexao();
			stm = conn.prepareStatement(sqlSelect);
			stm.setInt(1, ca.getNumero());
			rs = stm.executeQuery();
			if (rs.next()) {
				ca.setNumero(rs.getInt("numero"));
				ca.setMesa(rs.getInt("mesa"));
				ca.setEntrada(rs.getString("data_entrada"));
				ca.setSaida(rs.getString("data_saida"));
				ca.setGarcom(rs.getString("garcom"));
			}
			stm.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return ca;

	}
	
	public void excluir(PedidoTO ca)
	{
		String sql = "delete from item_pedido where Pedido_numero = ?";
		String sql2 = "delete from Pedido where numero = ?";
		
		try
    	{
	    	Connection con =  ConnectionFactory.obtemConexao();
	    	PreparedStatement prep = con.prepareStatement(sql);
	    	PreparedStatement prep2 = con.prepareStatement(sql2);
	    	prep.setInt(1,ca.getNumero());
	    	prep2.setInt(1,ca.getNumero());
	    	
	    	System.out.println(prep.toString());
	    	prep.execute();
	    	prep2.execute();
	    	prep.close();
	    	prep2.close();
    	}
    	 catch (Exception e) 
        { 
           e.printStackTrace(); 
           
        }
	}
	
	public void alterar(PedidoTO ca)
	{
		String sql = "update Pedido set mesa = ?, garcom = ? where numero = ?";
		
		try
    	{
	    	Connection con =  ConnectionFactory.obtemConexao();
	    	PreparedStatement prep = con.prepareStatement(sql);
	    	prep.setInt(1,ca.getMesa());
	    	prep.setString(2,ca.getGarcom());
	    	prep.setInt(3,ca.getNumero());
	    	
	    	System.out.println(prep.toString());
	    	prep.execute();
	    	prep.close();
    	}
    	 catch (Exception e) 
        { 
           e.printStackTrace(); 
           
        }
		
		
	}
}
