package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import banco.ConnectionFactory;
import to.ItemPedidoTO;

public class ItemPedidoDAO {

	public ItemPedidoDAO() {

	}

	public void incluir(ItemPedidoTO ca) {
		String sql = "insert into Item_PEDIDO values (?,?,?)";

		try {
			Connection con = ConnectionFactory.obtemConexao();
			PreparedStatement prep = con.prepareStatement(sql);
			prep.setInt(1, ca.getNumeroCardapio());
			prep.setInt(2, ca.getNumeroPedido());
			prep.setInt(3, ca.getQuantidade());

			System.out.println(prep.toString());
			prep.execute();
			prep.close();
		} catch (Exception e) {
			e.printStackTrace();

		}
	}

	public void incluir2(ItemPedidoTO ca) {
		String sql = "update item_pedido set quantidade = ? where pedido_numero = ? and cardapio_numero = ?";

		try {
			Connection con = ConnectionFactory.obtemConexao();
			PreparedStatement prep = con.prepareStatement(sql);
			prep.setInt(1, ca.getQuantidade());
			prep.setInt(2, ca.getNumeroPedido());
			prep.setInt(3, ca.getNumeroCardapio());
			System.out.println(prep);
			System.out.println(prep.toString());
			prep.execute();
			prep.close();
		} catch (Exception e) {
			e.printStackTrace();

		}
	}

	public void incluir3(ItemPedidoTO ca) {
		String sql = "insert into item_pedido values (?,?,?)";

		try {
			Connection con = ConnectionFactory.obtemConexao();
			PreparedStatement prep = con.prepareStatement(sql);
			prep.setInt(1, ca.getNumeroCardapio());
			prep.setInt(2, ca.getNumeroPedido());
			prep.setInt(3, ca.getQuantidade());
			System.out.println(prep);
			System.out.println(prep.toString());
			prep.execute();
			prep.close();
		} catch (Exception e) {
			e.printStackTrace();

		}
	}

	public ItemPedidoTO consultar(ItemPedidoTO ca) {
		String sqlSelect = "SELECT * FROM Item_Pedido WHERE pedido_numero = ?";

		PreparedStatement stm = null;
		ResultSet rs = null;
		try {
			Connection conn = ConnectionFactory.obtemConexao();
			stm = conn.prepareStatement(sqlSelect);
			stm.setInt(1, ca.getNumeroPedido());
			rs = stm.executeQuery();
			if (rs.next()) {
				ca.setNumeroCardapio(rs.getInt("cardapio_numero"));
				ca.setNumeroPedido(rs.getInt("pedido_numero"));
				ca.setQuantidade(rs.getInt("quantidade"));
			}
			stm.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return ca;

	}

	public int consultar2(ItemPedidoTO ca) {
		String sqlSelect = "SELECT count(Cardapio_numero) FROM Item_Pedido WHERE pedido_numero = ? and cardapio_numero = ?";

		PreparedStatement stm = null;
		ResultSet rs = null;
		int f = 0;
		try {
			Connection conn = ConnectionFactory.obtemConexao();
			stm = conn.prepareStatement(sqlSelect);
			stm.setInt(1, ca.getNumeroPedido());
			stm.setInt(1, ca.getNumeroCardapio());
			rs = stm.executeQuery();

			if (rs.next()) {
				f = rs.getInt("count(Cardapio_numero)");
			}
			stm.close();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			
		}
		return f;
	}

	public int consultar3(ItemPedidoTO ca) {
		String sqlSelect = "SELECT quantidade FROM Item_Pedido WHERE pedido_numero = ? and cardapio_numero = ?";

		PreparedStatement stm = null;
		ResultSet rs = null;
		try {
			Connection conn = ConnectionFactory.obtemConexao();
			stm = conn.prepareStatement(sqlSelect);
			stm.setInt(1, ca.getNumeroPedido());
			stm.setInt(2, ca.getNumeroCardapio());
			rs = stm.executeQuery();
			if (rs.next()) {
				// ca.setNumeroCardapio(rs.getInt("cardapio_numero"));
				// ca.setNumeroPedido(rs.getInt("pedido_numero"));
				ca.setQuantidade(rs.getInt("quantidade"));
			}
			stm.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return ca.getQuantidade();

	}

	public void excluir(ItemPedidoTO ca) {
		String sql = "delete from item_pedido where Pedido_numero = ? and cardapio_numero = ?";

		try {
			Connection con = ConnectionFactory.obtemConexao();
			PreparedStatement prep = con.prepareStatement(sql);
			prep.setInt(1, ca.getNumeroPedido());
			prep.setInt(1, ca.getNumeroCardapio());

			System.out.println(prep.toString());
			prep.execute();
			prep.close();
		} catch (Exception e) {
			e.printStackTrace();

		}
	}

	public String soma(ItemPedidoTO ca) {
		String sqlSelect = "select  SUM(c.valor_unitario * it.quantidade) from cardapio as c "
				+ "inner join item_pedido as it on c.numero = it.Cardapio_numero  " + "where it.Pedido_numero = ?";

		PreparedStatement stm = null;
		ResultSet rs = null;
		String f = "";
		double fo = 0.0;
		try {
			Connection conn = ConnectionFactory.obtemConexao();
			stm = conn.prepareStatement(sqlSelect);
			stm.setInt(1, ca.getNumeroPedido());
			rs = stm.executeQuery();

			if (rs.next()) {
				fo = rs.getDouble("SUM(c.valor_unitario * it.quantidade)");
				f = String.valueOf(fo);
			}
			stm.close();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			
			
		}
		return f;
	}

}
