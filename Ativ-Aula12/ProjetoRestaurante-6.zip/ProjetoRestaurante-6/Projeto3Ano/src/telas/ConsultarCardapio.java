package telas;

import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ResourceBundle;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import service.CardapioService;
import to.CardapioTO;

public class ConsultarCardapio extends JDialog implements ActionListener {
	
	private JPanel pn1, pn2, pn3;
	private JLabel lb1;
	private JButton but1, but2;
	private JTextField txt1, txt2, txt3;
	private JTextArea area;
	
	private ResourceBundle bn = ResourceBundle.getBundle("ex1",Internacionalizar.local);
	
	public ConsultarCardapio()
	{
		setModal(true);
		setTitle(bn.getString("p56"));
		
		Container cont1 = getContentPane();
		cont1.setLayout(new GridLayout(3,1));
		
		pn1 = new JPanel();
		pn1.setLayout(new GridLayout(1,3,10,10));		
		
      pn2 = new JPanel();
		pn2.setLayout(new FlowLayout());
		
		pn3 = new JPanel();
		pn3.setLayout(new GridLayout(1,3,10,10));
		
		//JAREA
		area = new JTextArea();
		//JLABELS
		lb1 = new JLabel(bn.getString("p57"));
        
      //TEXT FIELDS
		txt1 = new JTextField(10);
		txt2 = new JTextField(10);
		txt3 = new JTextField(10);
		
		txt2.setVisible(false);
		txt2.setEditable(false);
		txt3.setVisible(false);
		txt3.setEditable(false);

		//BOT�ES
		but1 = new JButton(bn.getString("p58"));
		but2 = new JButton(bn.getString("p59"));
      
		
		//A��O AOS BOT�ES
		but1.addActionListener(this);
		getRootPane().setDefaultButton(but1); // precionando ENTER
		
		but2.addActionListener(this);
		
			//PAINEL 1
		pn1.add(lb1);
		pn1.add(txt1);
		pn1.add(but1);
		
		cont1.add(pn1);
		
		//PAINEL 2
		pn2.add(area);
		cont1.add(pn2);
		
		//PAINEL 3
		pn3.add(but2);
		pn3.add(txt2);
		pn3.add(txt3);
		
		cont1.add(pn3);
		
		setLocation(400,100);
		setSize(665,300);
		setVisible(true);
	      
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
	}//FIM DO CONTRUTOR
	
	public void actionPerformed(ActionEvent e)
	{
		try
		{
			if(e.getSource() == but1)
			{
				CardapioService ca = new CardapioService();
				CardapioTO to = new CardapioTO();
				to.setNumero(Integer.parseInt(txt1.getText()));
				//CardapioDAO card = new CardapioDAO();
				ca.consultar(to);
				
				if(to.getDescricao() != null)
				{
					area.setText(to.getNumero()+" "+to.getDescricao()+" "+to.getValorUnit());
				}
			}
			if(e.getSource() == but2)
			{
				this.dispose();
			}
			
		}
		catch(Exception ex)
		{
			JOptionPane.showMessageDialog(null,"ERRO");
		}
	}//ActionPerformed
	
	public static void main(String args[])
	{
		ConsultarCardapio men = new ConsultarCardapio();
	}
}//FIM DA CLASSE
