package telas;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.ResourceBundle;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import logica.Criptografia;
import logica.ReadTextFile;

public class Login extends JDialog implements ActionListener {

	public static String z, y, senha, usuario, cargo, nomeUsuario;
	
	

//	public static void setNomeUsuario(String nomeUsuario) {
//		Login.nomeUsuario = nomeUsuario;
//	}

	public static String getNomeUsuario() {
		return nomeUsuario;
	}

	public static void setNomeUsuario(String n) {
		nomeUsuario = n;
	}

	private String Login;
	private JPanel pn1, pn2;
	private JLabel lb1, lb2;
	private JButton but1;
	private JTextField txt1, txt3, txt4, txt5;
	private JPasswordField txt2;
	private ResourceBundle bn = ResourceBundle.getBundle("ex1", Internacionalizar.local);
	ArrayList<String> usuarios = new ArrayList<String>();
	private Scanner ler2;
	private BufferedReader ler;
	byte[] bMsgClara = null;
	byte[] bMsgCifrada = null;
	byte[] bMsgDecifrada = null;
	String sMsgDecifrada = null;
	String sMsgCifrada = null;

	public Login() {
		setModal(true);
		setTitle(bn.getString("p123"));

		Container cont1 = getContentPane();
		cont1.setLayout(new GridLayout(2, 1));

		pn1 = new JPanel();
		pn1.setLayout(new GridLayout(4, 1));

		pn2 = new JPanel();
		pn2.setLayout(new GridLayout(2, 2));

		// JLABELS
		lb1 = new JLabel(bn.getString("p124"));
		lb2 = new JLabel(bn.getString("p125"));

		// TEXT FIELDS
		txt1 = new JTextField(10);
		txt2 = new JPasswordField("Senha");
		txt3 = new JTextField(10);
		txt4 = new JTextField(10);
		txt5 = new JTextField(10);

		txt3.setVisible(false);
		txt3.setEditable(false);

		txt4.setVisible(false);
		txt4.setEditable(false);

		txt5.setVisible(false);
		txt5.setEditable(false);

		// BOT�ES
		but1 = new JButton(bn.getString("p126"));// Login

		// A��O AOS BOT�ES
		but1.addActionListener(this);

		// PAINEL 1
		pn1.add(lb1);
		pn1.add(txt1);
		pn1.add(lb2);
		pn1.add(txt2);

		cont1.add(pn1);

		// PAINEL 2
		pn2.add(txt3);
		pn2.add(txt4);
		pn2.add(txt5);
		pn2.add(but1);

		cont1.add(pn2);

		setLocation(650, 420);
		setSize(300, 240);
		setVisible(true);

		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

	}// FIM DO CONTRUTOR

	// A��O BOT�ES
	public void actionPerformed(ActionEvent e) {
		try {
			if (e.getSource() == but1) {

				try {

					Criptografia p = new Criptografia();

					senha = txt2.getText();
					usuario = txt1.getText();

					p.Cript("login.txt", "decifra.txt", "moto", 'D');

					ReadTextFile read = new ReadTextFile();
					read.openFile();
					String stringao = read.readRecords();
					read.closeFile();
					//JOptionPane.showMessageDialog(null, stringao);

					String[] textoSeparado = stringao.split(";");

					System.out.println(Arrays.toString(textoSeparado));

					String xxx = Arrays.toString(textoSeparado);

					String logins[] = { textoSeparado[0], textoSeparado[3], textoSeparado[6] };
					String senhas[] = { textoSeparado[1], textoSeparado[4], textoSeparado[7] };
					String cargos[] = { textoSeparado[2], textoSeparado[5], textoSeparado[8] };

					System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!" + xxx);
					try {

						File file = new File("decifra.txt");

						if (file.delete()) {
							System.out.println(file.getName() + " is deleted!");
						} else {
							System.out.println("Delete operation is failed.");
						}

					} catch (Exception ex) {

						ex.printStackTrace();

					}
					
					for(int i = 0 ; i < logins.length ; i++)
					{
						if(usuario.equals(logins[i]))
						{
							nomeUsuario = logins[i];
							
							if(senha.equals(senhas[i]))
							{
								cargo = cargos[i];
								
								if(cargo.equals("a"))
								{
									cargo = "a";
									MenuPrincipal name = new MenuPrincipal();
									name.verificar();
									this.dispose();
								}
								if(cargo.equals("c"))
								{
									cargo = "c";
									MenuPrincipal name = new MenuPrincipal();
									name.verificar();
									this.dispose();
								}
								if(cargo.equals("g"))
								{
									cargo = "g";
									MenuPrincipal name = new MenuPrincipal();
									name.verificar();
									this.dispose();
								}
							}
						}
					}
					

				} catch (Exception ex) {
					JOptionPane.showMessageDialog(null, "ERRO NO ARQUIVO", "ATEN��O", JOptionPane.PLAIN_MESSAGE);
				}
				
			}

		} catch (Exception ex) {
			JOptionPane.showMessageDialog(null, "Erro de Opera��o");
		}
	}// ActionPerformed

	public static void main(String args[]) {
		Login men = new Login();

	}
}// FIM DA CLASSE
