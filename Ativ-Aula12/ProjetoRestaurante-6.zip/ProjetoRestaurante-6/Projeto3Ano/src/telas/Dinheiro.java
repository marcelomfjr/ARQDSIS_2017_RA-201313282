package telas;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ResourceBundle;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Dinheiro extends JDialog implements ActionListener {
	
	private JPanel pn1, pn2;
	private JLabel lb1,lb2;
	private JButton but1, but2;
	private JTextField txt1, txt2;
	private ResourceBundle bn = ResourceBundle.getBundle("ex1",Internacionalizar.local);
	
	public Dinheiro()
	{
		setModal(true);
		setTitle(bn.getString("p97"));
		
		Container cont1 = getContentPane();
		cont1.setLayout(new GridLayout(2,1));
		
		pn1 = new JPanel();
		pn1.setLayout(new GridLayout(2,2));		
		
      pn2 = new JPanel();
		pn2.setLayout(new GridLayout(1,2,20,20));
		
		
		
		//JLABELS
		lb1 = new JLabel(bn.getString("p98"));
		lb2 = new JLabel(bn.getString("p99"));
      
      
      
		//TEXT FIELDS
		txt1 = new JTextField(10);
		txt2 = new JTextField(10);
		
		txt2.setEditable(false);
		
		Action action = new AbstractAction()
		{
		    @Override
		    public void actionPerformed(ActionEvent e)
		    {
				double pag = Double.parseDouble(txt1.getText());
				double troco = pag - FecharConta.total;
				
				txt2.setText("R$ " + FecharConta.df.format(troco));
				
		    }
		};
		
		txt1.addActionListener(action);;
				
		//BOT�ES
		but1 = new JButton(bn.getString("p100"));
		but2 = new JButton(bn.getString("p101"));
		
		//A��O AOS BOT�ES
		but1.addActionListener(this);
		but2.addActionListener(this);
		
			//PAINEL 1
		pn1.add(lb1);
		pn1.add(txt1);
      pn1.add(lb2);
      pn1.add(txt2);
      
	
		cont1.add(pn1);
		
		//PAINEL 2
      pn2.add(but1);
      pn2.add(but2);
		
      cont1.add(pn2);
		
		setLocation(650,420);
	   setSize(500,180);
	   setVisible(true);
	      
	   setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
	}//FIM DO CONTRUTOR
	
	public void actionPerformed(ActionEvent e)
	{
		try
		{
			if(e.getSource() == but1)
			{
				this.dispose();
				FormaPagamento men = new FormaPagamento();
			}
			if(e.getSource() == but2)
			{
				this.dispose();
				JOptionPane.showMessageDialog(null, "Conta Paga!");
			}
			
		}
		catch(Exception ex)
		{
			JOptionPane.showMessageDialog(null,"ERRO");
		}
	}//ActionPerformed
	
	public static void main(String args[])
	{
		Dinheiro men = new Dinheiro();
	}
}//FIM DA CLASSE
