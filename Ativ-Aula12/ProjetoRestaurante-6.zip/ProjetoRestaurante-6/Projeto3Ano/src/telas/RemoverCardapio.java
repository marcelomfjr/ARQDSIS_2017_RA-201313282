package telas;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ResourceBundle;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import service.CardapioService;
import to.CardapioTO;

public class RemoverCardapio extends JDialog implements ActionListener {

	private JPanel pn1, pn2, pn3;
	private JLabel lb1;
	private JButton but1, but2;
	private JTextField txt1;
	private JTextArea area;

	private ResourceBundle bn = ResourceBundle.getBundle("ex1", Internacionalizar.local);

	public RemoverCardapio() {
		setModal(true);
		setTitle(bn.getString("p60"));

		Container cont1 = getContentPane();
		cont1.setLayout(new GridLayout(3, 1));

		pn1 = new JPanel();
		pn1.setLayout(new GridLayout(1, 2, 10, 10));

		pn2 = new JPanel();
		pn2.setLayout(new FlowLayout());

		pn3 = new JPanel();
		pn3.setLayout(new GridLayout(1, 2, 10, 10));

		// JLABELS
		lb1 = new JLabel(bn.getString("p61"));
		lb1.setPreferredSize(new Dimension(200, 30));

		// JAREA
		area = new JTextArea();

		// TEXT FIELDS
		txt1 = new JTextField(10);

		txt1.setPreferredSize(new Dimension(00, 30));

		// BOT�ES
		but1 = new JButton(bn.getString("p62"));
		but2 = new JButton(bn.getString("p63"));

		/*
		 * but1.setFont(new Font("TimesRoman",Font.BOLD,20)); but2.setFont(new
		 * Font("TimesRoman",Font.BOLD,20));
		 */

		// A��O AOS BOT�ES
		but1.addActionListener(this);
		but2.addActionListener(this);

		// PAINEL 1
		pn1.add(lb1);
		pn1.add(txt1);

		cont1.add(pn1);

		// PAINEL 2
		pn2.add(area);
		cont1.add(pn2);

		// PAINEL 3
		pn3.add(but2);
		pn3.add(but1);

		cont1.add(pn3);

		setLocation(300, 100);
		setSize(665, 300);
		setVisible(true);

		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

	}// FIM DO CONTRUTOR

	public void actionPerformed(ActionEvent e) {
		try {
			if (e.getSource() == but1) {
				CardapioService ca = new CardapioService();
				CardapioTO to = new CardapioTO();
				to.setNumero(Integer.parseInt(txt1.getText()));
//				CardapioDAO card = new CardapioDAO();
				ca.consultar(to);
//				card.excluir(ca);
//				card.consultar(ca);

				if (to.getDescricao() != null) {
					area.setText("Produto Deletado: " + to.getNumero() + " " + to.getDescricao() + " R$ " + to.getValorUnit());
					ca.excluir(to);
				}
			}
			if (e.getSource() == but2) {
				this.dispose();
			}

		} catch (Exception ex) {
			JOptionPane.showMessageDialog(null, "ERRO");
		}
	}// ActionPerformed

	public static void main(String args[]) {
		RemoverCardapio men = new RemoverCardapio();
	}
}// FIM DA CLASSE
