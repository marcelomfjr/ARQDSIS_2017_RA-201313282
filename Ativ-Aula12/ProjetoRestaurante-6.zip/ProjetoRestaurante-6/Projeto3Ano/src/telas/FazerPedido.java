package telas;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.ResourceBundle;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import service.CardapioService;
import service.ItemPedidoService;
import service.PedidoService;
import to.CardapioTO;
import to.ItemPedidoTO;
import to.PedidoTO;

public class FazerPedido extends JDialog implements ActionListener {
	
	private JPanel pn1, pn2, pn3;
	private JLabel lb1, lb2, lb3, lb4;
	private JButton but1, but2, but3, but4;
	private JTextField txt1, txt2, txt3, txt4;
	private JTextArea area;
	
	private ResourceBundle bn = ResourceBundle.getBundle("ex1",Internacionalizar.local);
	
	public FazerPedido()
	{
		setModal(true);
		setTitle(bn.getString("p7"));
		
		Container cont1 = getContentPane();
		cont1.setLayout(new GridLayout(3,1));
		
		pn1 = new JPanel();
		pn1.setLayout(new GridLayout(4,2));
		
		pn2 = new JPanel();
		pn2.setLayout(new FlowLayout());
		
		pn3 = new JPanel();
		pn3.setLayout(new GridLayout(2,2,50,50));
		
		//JLABELS
		lb1 = new JLabel(bn.getString("p8"));
		lb2 = new JLabel(bn.getString("p9"));
		lb3 = new JLabel(bn.getString("p10"));
		lb4 = new JLabel(bn.getString("p11"));
		
		//BOT�ES
		but1 = new JButton(bn.getString("p12"));
		but2 = new JButton(bn.getString("p13"));
		but3 = new JButton(bn.getString("p14"));
		but4 = new JButton(bn.getString("p15"));
		
		but1.addActionListener(this);
		//but2.addActionListener(this);
		but3.addActionListener(this);
		//but4.addActionListener(this);
		
		but2.setEnabled(false);
		but4.setEnabled(false);
		but2.setVisible(false);
		but4.setVisible(false);
		
		//JAREA
		area = new JTextArea();
		
		//TEXT FIELDS
		txt1 = new JTextField(10);
		txt2 = new JTextField(10);
		txt3 = new JTextField(10);
		txt4 = new JTextField(10);
		
		//PAINEL 1
		pn1.add(lb1);
		pn1.add(txt1);
		pn1.add(lb2);
		pn1.add(txt2);
		pn1.add(lb3);
		pn1.add(txt3);
		pn1.add(but2);
		pn1.add(but1);
		
		cont1.add(pn1);
		
		//PAINEL 2
		pn2.add(area);
		cont1.add(pn2);
		
		//PAINEL 3
		pn3.add(lb4);
		pn3.add(txt4);
		pn3.add(but3);
		pn3.add(but4);
		
		cont1.add(pn3);
		
		setLocation(300,100);
	    setSize(665,600);
	    setVisible(true);
	      
	    setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
	}//FIM DO CONTRUTOR
	
	public void actionPerformed(ActionEvent e)
	{
		try
		{
			if(e.getSource() == but1)
			{
				//Login.setNomeUsuario("Luiz");
				
				CardapioTO to = new CardapioTO();
				CardapioService cmod = new CardapioService();
				to.setNumero(Integer.parseInt(txt2.getText()));
				cmod.consultar(to);
				
				if(to.getDescricao() == null)
				{
					JOptionPane.showMessageDialog(null,"Produto n�o existe");
				}
				
				area.setText(to.getNumero()+" "+to.getDescricao()+" "+to.getValorUnit());
				SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				Calendar cal = Calendar.getInstance();
				String formatted = format1.format(cal.getTime());
//				JOptionPane.showMessageDialog(null, formatted);

				PedidoTO pod = new PedidoTO();
				PedidoService pdao = new PedidoService();
				pod.setNumero(Integer.parseInt(txt4.getText()));
				pod.setMesa(Integer.parseInt(txt1.getText()));
				pod.setGarcom(Login.getNomeUsuario());
				pod.setEntrada(formatted);
				
				ItemPedidoService imod = new ItemPedidoService();
				ItemPedidoTO idao = new ItemPedidoTO();
				
				idao.setNumeroCardapio(Integer.parseInt(txt2.getText()));
				idao.setNumeroPedido(Integer.parseInt(txt4.getText()));
				idao.setQuantidade(Integer.parseInt(txt3.getText()));
				
				int op1 = pdao.consultar2(pod);
				int op2 = imod.consultar2(idao);
				
				//JOptionPane.showMessageDialog(null, op1 +"     "+op2);
				if(op1 == 0)//NENHUM PEDIDO FEITO
				{
					pdao.criar(pod);
					imod.criar(idao);
				}

				else if(op2 == 1)
				{
					int soma = imod.consultar3(idao);
					idao.setQuantidade(soma + idao.getQuantidade());
					System.out.println(imod);
					imod.criar2(idao);
					
					System.out.println(soma);
				}
				else if(op2 == 0)//INCLUIR OUTRO ITEM
				{
					imod.criar3(idao);
				}
				
			}
			if(e.getSource() == but2)
			{
				
			}
			if(e.getSource() == but3)
			{
				this.dispose();
			}
			if(e.getSource() == but4)
			{
				
			}
		}
		catch(Exception ex)
		{
			JOptionPane.showMessageDialog(null,"ERRO");
			ex.printStackTrace();
		}
	}//ActionPerformed
	
	public static void main(String args[])
	{
		FazerPedido men = new FazerPedido();
	}
}//FIM DA CLASSE
