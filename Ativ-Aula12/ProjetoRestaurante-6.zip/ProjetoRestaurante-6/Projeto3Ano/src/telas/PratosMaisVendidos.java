package telas;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ResourceBundle;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

public class PratosMaisVendidos extends JDialog implements ActionListener {
	
	private JPanel pn1, pn2, pn3;
	private JLabel lb1, lb2, lb3;
	private JButton but1, but2;
	private JTextField txt1, txt2, txt3, txt4, txt5, txt6, txt7, txt8, txt9, txt10;
	private JRadioButton rb1, rb2, rb3, rb4, rb5;
	private ButtonGroup bg1, bg2;
	
	private ResourceBundle bn = ResourceBundle.getBundle("ex1",Internacionalizar.local);
	
	public PratosMaisVendidos()
	{
		setModal(true);
		setTitle(bn.getString("p112"));
		
		Container cont1 = getContentPane();
		cont1.setLayout(new GridLayout(3,1,0,40));
		
		pn1 = new JPanel();
		pn1.setLayout(new GridLayout(4,4));		
		
		pn2 = new JPanel();
		pn2.setLayout(new FlowLayout());
		
		pn3 = new JPanel();
		pn3.setLayout(new GridLayout(1,4));
		
		//JLABELS
		lb1 = new JLabel(bn.getString("p113"));
		lb2 = new JLabel(bn.getString("p114"));
		lb3 = new JLabel(bn.getString("p115"));
      
		//TEXT FIELDS
		txt1 = new JTextField(10);
		
		txt2 = new JTextField(10);
		txt3 = new JTextField(10);
		txt4 = new JTextField(10);
		txt5 = new JTextField(10);
		txt6 = new JTextField(10);
		txt7 = new JTextField(10);
		txt8 = new JTextField(10);
		txt9 = new JTextField(10);
		txt10 = new JTextField(10);
		
		txt2.setVisible(false);
		txt2.setEditable(false);
		txt3.setVisible(false);
		txt3.setEditable(false);
		txt4.setVisible(false);
		txt4.setEditable(false);
		txt5.setVisible(false);
		txt5.setEditable(false);
		txt6.setVisible(false);
		txt6.setEditable(false);
		txt7.setVisible(false);
		txt7.setEditable(false);
		txt8.setVisible(false);
		txt8.setEditable(false);
		txt9.setVisible(false);
		txt9.setEditable(false);
		txt10.setVisible(false);
		txt10.setEditable(false);
				
		//BOT�ES
		but1 = new JButton(bn.getString("p116"));
		but2 = new JButton(bn.getString("p117"));
		
		//RADIO BUTTONS
		rb1 = new JRadioButton(bn.getString("p118"));
		rb2 = new JRadioButton(bn.getString("p119"));
		rb3 = new JRadioButton(bn.getString("p120"));
		
		bg1 = new ButtonGroup();
		bg1.add(rb1);
		bg1.add(rb2);
		bg1.add(rb3);
		
		rb4 = new JRadioButton(bn.getString("p121"));
		rb5 = new JRadioButton(bn.getString("p122"));
		
		bg2 = new ButtonGroup();
		bg2.add(rb4);
		bg2.add(rb5);
		
		//A��O AOS BOT�ES
		but1.addActionListener(this);
		but2.addActionListener(this);
		
			//PAINEL 1
		pn1.add(lb1);
		pn1.add(txt1);
		pn1.add(txt2);
		pn1.add(txt3);
		pn1.add(lb2);
		pn1.add(rb1);
		pn1.add(rb2);
		pn1.add(rb3);
		pn1.add(lb3);
		pn1.add(rb4);
		pn1.add(rb5);
		pn1.add(txt4);
		pn1.add(but1);
		pn1.add(txt5);
		pn1.add(txt6);
		pn1.add(txt7);
	
		cont1.add(pn1);
		
		//PAINEL 2
		cont1.add(pn2);
		
		//PAINEL 3
		pn3.add(but2);
		pn3.add(txt8);
		pn3.add(txt9);
		pn3.add(txt10);
		
		cont1.add(pn3);
		
		setLocation(400,100);
	   setSize(665,300);
	   setVisible(true);
	      
	   setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
	}//FIM DO CONTRUTOR
	
	public void actionPerformed(ActionEvent e)
	{
		try
		{
			if(e.getSource() == but1)
			{
				
			}
			if(e.getSource() == but2)
			{
				this.dispose();
			}
			
		}
		catch(Exception ex)
		{
			JOptionPane.showMessageDialog(null,"ERRO");
		}
	}//ActionPerformed
	
	public static void main(String args[])
	{
		PratosMaisVendidos men = new PratosMaisVendidos();
	}
}//FIM DA CLASSE
