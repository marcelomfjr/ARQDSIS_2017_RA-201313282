package telas;

import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ResourceBundle;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import service.PedidoService;
import to.PedidoTO;

public class RemoverPedido extends JDialog implements ActionListener {

	private JPanel pn1, pn2, pn3;
	private JLabel lb1;
	private JButton but1, but2;
	private JTextField txt1;
	private JTextArea area;

	private ResourceBundle bn = ResourceBundle.getBundle("ex1", Internacionalizar.local);

	public RemoverPedido() {
		setModal(true);
		setTitle(bn.getString("p27"));

		Container cont1 = getContentPane();
		cont1.setLayout(new GridLayout(3, 1));

		pn1 = new JPanel();
		pn1.setLayout(new GridLayout(1, 2));

		pn2 = new JPanel();
		pn2.setLayout(new FlowLayout());

		pn3 = new JPanel();
		pn3.setLayout(new GridLayout(1, 4));

		// JLABELS
		lb1 = new JLabel(bn.getString("p28"));

		// JAREA
//		area = new JTextArea(200,200);

		// BOT�ES
		but1 = new JButton(bn.getString("p29"));
		but2 = new JButton(bn.getString("p30"));

		but1.addActionListener(this);
		but2.addActionListener(this);

		// TEXT FIELDS
		txt1 = new JTextField(10);

		// PAINEL 1
		pn1.add(lb1);
		pn1.add(txt1);

		cont1.add(pn1);

		// PAINEL 2
//		pn2.add(area);
		cont1.add(pn2);

		// PAINEL 3
		pn3.add(but1);
		pn3.add(but2);

		cont1.add(pn3);

		setLocation(500, 300);
		setSize(665, 600);
		setVisible(true);

		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

	}// FIM DO CONTRUTOR

	public void actionPerformed(ActionEvent e) {
		try {
			if (e.getSource() == but1) {
				this.dispose();
			}
			if (e.getSource() == but2) {
				PedidoService pod = new PedidoService();
				PedidoTO pdao = new PedidoTO();

				pdao.setNumero(Integer.parseInt(txt1.getText()));
				
//				area.setText("Pedido Deletado: " + pod.getNumero());

				pod.excluir(pdao);

				// ItemPedidoModel imod = new ItemPedidoModel();
				// ItemPedidoDAO idao = new ItemPedidoDAO();
				//
				// imod.setNumeroPedido(Integer.parseInt(txt1.getText()));

			}
		} catch (Exception ex) {
			JOptionPane.showMessageDialog(null, "ERRO");
		}
	}// ActionPerformed

	public static void main(String args[]) {
		RemoverPedido men = new RemoverPedido();
	}
}// FIM DA CLASSE
