package telas;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ResourceBundle;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class FinalizarPrato extends JDialog implements ActionListener {
	
	private JPanel pn1, pn2;
	private JLabel lb1;
	private JButton but1;
	private JTextField txt1;
	private ResourceBundle bn = ResourceBundle.getBundle("ex1",Internacionalizar.local);
	
	public FinalizarPrato()
	{
		setModal(true);
		setTitle(bn.getString("p68"));
		
		Container cont1 = getContentPane();
		cont1.setLayout(new GridLayout(2,1));
		
		pn1 = new JPanel();
		pn1.setLayout(new GridLayout(1,2,10,10));		
		
      pn2 = new JPanel();
		pn2.setLayout(new GridLayout(1,3));
		
		
		
		//JLABELS
		lb1 = new JLabel(bn.getString("p69"));
      
      
      
      //TEXT FIELDS
		txt1 = new JTextField(10);
      
      
				
		//BOT�ES
		but1 = new JButton(bn.getString("p70"));
		
		
		//A��O AOS BOT�ES
		but1.addActionListener(this);
		
		
	   //PAINEL 1
		cont1.add(pn1);
		
		//PAINEL 2
		pn2.add(lb1);
		pn2.add(txt1);
      pn2.add(but1);
      
      cont1.add(pn2);
      
		
		
		
		setLocation(500,300);
	   setSize(665,200);
	   setVisible(true);
	      
	   setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
	}//FIM DO CONTRUTOR
	
	public void actionPerformed(ActionEvent e)
	{
		try
		{
			if(e.getSource() == but1)
			{
				
			}
			
			
		}
		catch(Exception ex)
		{
			JOptionPane.showMessageDialog(null,"ERRO");
		}
	}//ActionPerformed
	
	public static void main(String args[])
	{
		FinalizarPrato men = new FinalizarPrato();
	}
}//FIM DA CLASSE
