package telas;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ResourceBundle;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class PriorizarPedido extends JDialog implements ActionListener {
	
	private JPanel pn1, pn2, pn3;
	private JLabel lb1, lb2;
	private JButton but1, but2 ;
	private JTextField txt1, txt2, txt3, txt4, txt5;
	
	private ResourceBundle bn = ResourceBundle.getBundle("ex1",Internacionalizar.local);
	
	public PriorizarPedido()
	{
		setModal(true);
		setTitle(bn.getString("p31"));
		
		Container cont1 = getContentPane();
		cont1.setLayout(new GridLayout(3,1,50,50));
		
		pn1 = new JPanel();
		pn1.setLayout(new FlowLayout());
		
		pn2 = new JPanel();
		pn2.setLayout(new GridLayout(1,5));
		
		pn3 = new JPanel();
		pn3.setLayout(new GridLayout(1,4,50,50));
		
		//JLABELS
		lb1 = new JLabel(bn.getString("p32"));
		lb2 = new JLabel(bn.getString("p33"));
		
		//BOT�ES
		but1 = new JButton(bn.getString("p34"));
		but2 = new JButton(bn.getString("p35"));
		
		but1.addActionListener(this);
		but2.addActionListener(this);

		
		//TEXT FIELDS
		txt1 = new JTextField(10);
		txt2 = new JTextField(10);
		txt3 = new JTextField(10);
		txt4 = new JTextField(10);
		txt5 = new JTextField(10);
		
		txt3.setVisible(false);
		txt3.setEditable(false);
		txt4.setVisible(false);
		txt4.setVisible(false);
		txt5.setVisible(false);
		txt5.setEditable(false);
		
		//PAINEL 1
		cont1.add(pn1);
		
		//PAINEL 2
		pn2.add(lb1);
		pn2.add(txt1);
		pn2.add(lb2);
		pn2.add(txt2);
		pn2.add(but1);
		
		cont1.add(pn2);
		
		//PAINEL 3
		pn3.add(but2);
		pn3.add(txt3);
		pn3.add(txt4);
		pn3.add(txt5);
		
		cont1.add(pn3);
		
		setLocation(500,300);
	    setSize(665,600);
	    setVisible(true);
	      
	    setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
	}//FIM DO CONTRUTOR
	
	public void actionPerformed(ActionEvent e)
	{
		try
		{
			if(e.getSource() == but1)
			{
				
			}
			if(e.getSource() == but2)
			{
				this.dispose();
			}
		}
		catch(Exception ex)
		{
			JOptionPane.showMessageDialog(null,"ERRO");
		}
	}//ActionPerformed
	
	public static void main(String args[])
	{
		PriorizarPedido men = new PriorizarPedido();
	}
}//FIM DA CLASSE
