package to;

import java.util.Calendar;

public class PedidoTO {
	
	private int numero, mesa;
	String entrada, saida;
	Calendar cEntrada, cSaida;
	private String garcom;
	public int getNumero() {
		return numero;
	}
	public void setNumero(int numero) {
		this.numero = numero;
	}
	public int getMesa() {
		return mesa;
	}
	public void setMesa(int mesa) {
		this.mesa = mesa;
	}
	public String getEntrada() {
		return entrada;
	}
	public void setEntrada(String entrada) {
		this.entrada = entrada;
	}
	public String getSaida() {
		return saida;
	}
	public void setSaida(String saida) {
		this.saida = saida;
	}
	public Calendar getcEntrada() {
		return cEntrada;
	}
	public void setcEntrada(Calendar cEntrada) {
		this.cEntrada = cEntrada;
	}
	public Calendar getcSaida() {
		return cSaida;
	}
	public void setcSaida(Calendar cSaida) {
		this.cSaida = cSaida;
	}
	public String getGarcom() {
		return garcom;
	}
	public void setGarcom(String garcom) {
		this.garcom = garcom;
	}
	
	

}
