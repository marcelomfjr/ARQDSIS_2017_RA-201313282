package to;

public class ItemPedidoTO {
	
	private int numeroCardapio, numeroPedido, quantidade;

	public int getNumeroCardapio() {
		return numeroCardapio;
	}

	public void setNumeroCardapio(int numeroCardapio) {
		this.numeroCardapio = numeroCardapio;
	}

	public int getNumeroPedido() {
		return numeroPedido;
	}

	public void setNumeroPedido(int numeroPedido) {
		this.numeroPedido = numeroPedido;
	}

	public int getQuantidade() {
		return quantidade;
	}

	public void setQuantidade(int quantidade) {
		this.quantidade = quantidade;
	}
	
	

}
