package service;

import dao.CardapioDAO;
import to.CardapioTO;

public class CardapioService {
	
	//Atributos
	private CardapioDAO dao;
	
	//Construtores	
	public CardapioService()
	{	
		dao = new CardapioDAO();
	}
	
	
	//SERVICES
	public void criar(CardapioTO to)
	{
		dao.incluir(to);
	}
	
	public void alterar(CardapioTO to)
	{
		dao.alterar(to);
	}
	
	public void excluir(CardapioTO to)
	{

		dao.excluir(to);
	}
	
	public CardapioTO consultar(CardapioTO to)
	{
		return dao.consultar(to);
	}
	

}
