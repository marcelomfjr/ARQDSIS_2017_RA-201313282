package service;

import dao.ItemPedidoDAO;
import to.CardapioTO;
import to.ItemPedidoTO;

public class ItemPedidoService {

	private ItemPedidoDAO dao;
	
	public ItemPedidoService()
	{
		dao = new ItemPedidoDAO();
	}

//	public ItemPedidoService(int numeroCardapio, int numeroPedido, int quantidade) {
//		this.numeroCardapio = numeroCardapio;
//		this.numeroPedido = numeroPedido;
//		this.quantidade = quantidade;
//	}
//	
//	public ItemPedidoService()
//	{
//		numeroCardapio = 0;
//		numeroPedido = 0;
//		quantidade = 0;
//	}

	//SERVICES
		public void criar(ItemPedidoTO to)
		{
			dao.incluir(to);
		}
		
		public void criar2(ItemPedidoTO to)
		{
			dao.incluir(to);
		}
		
		public void criar3(ItemPedidoTO to)
		{
			dao.incluir(to);
		}
		
		
		public void excluir(ItemPedidoTO to)
		{

			dao.excluir(to);
		}
		
		public ItemPedidoTO consultar(ItemPedidoTO to)
		{
			return dao.consultar(to);
		}
		
		public int consultar2(ItemPedidoTO to)
		{
			return dao.consultar2(to);
		}
		
		public int consultar3(ItemPedidoTO to)
		{
			return dao.consultar3(to);
		}
		
		
	
	
	
	
}
